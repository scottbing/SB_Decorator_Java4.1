package com.company;

public interface Pizza {

    public String getDescription();

    public Double getCost();

}

